/*
 * parameter.h
 *
 *  Created on: 2026年10月19日
 *      Author: user
 */

#ifndef INC_I2C_PARAMETER_H_
#define INC_I2C_PARAMETER_H_


#include "stm32f4xx_hal.h"       // 核心HAL库
#include "stm32f4xx_hal_i2c.h"   // I2C外设支持
#include "stdbool.h"

// 通过外部声明引用全局变量
//extern I2C_HandleTypeDef hi2c1;  // I2C实例（在main.c中定义）

/* [共用 I2C 配置] 修改原 EEPROM 的 I2C 句柄为通用名称 */
// 原文件 eeprom_handler.h 中修改：
// extern I2C_HandleTypeDef* hi2c_eeprom; --> 修改为：
//extern I2C_HandleTypeDef* hi2c_main;    // [MOD] 重命名为通用I2C句柄




// 专用配置宏（替代包含main.h）
/* 硬件配置 (根据实际电路修改) -------------------------------------------------*/
/**
 * @brief EEPROM位址
 * @def EEPROM_I2C_ADDR
 * EEPROM的位址由A0,A1,A2來決定
 *| A2 | A1 | A0 | 7-bit地址（二進制） | 16 進制 |
 *|--- |--- |--- | ------------------ |---------|
 *| 0  | 0  | 0  | `1010000`          |  0x50   |
 *| 0  | 0  | 1  | `1010001`          |  0x51   |
 *| 0  | 1  | 0  | `1010010`          |  0x52   |
 *| 0  | 1  | 1  | `1010011`          |  0x53   |
 *| 1  | 0  | 0  | `1010100`          |  0x54   |
 *| 1  | 0  | 1  | `1010101`          |  0x55   |
 *| 1  | 1  | 0  | `1010110`          |  0x56   |
 *| 1  | 1  | 1  | `1010111`          |  0x57   |
 *
 */

//#define EEPROM_with_ds1370
#define EEPROM_with_AT24C02
#define RTC_DS3231_Temp
#define use_TCA9548

#ifdef use_TCA9548

/* TCA9548A 基本資訊 */
#define TCA9548_I2C_ADDR     0x70   // 7-bit 位址（A0-A2 全接地）
#define TCA9548_REG_CTRL     0x00   // 控制暫存器（寫入即選通道）

/* 通道位元遮罩（可多通道同時開啟，但一般只用一個） */
#define TCA9548_CH0   0x01
#define TCA9548_CH1   0x02
#define TCA9548_CH2   0x04
#define TCA9548_CH3   0x08
#define TCA9548_CH4   0x10
#define TCA9548_CH5   0x20
#define TCA9548_CH6   0x40
#define TCA9548_CH7   0x80

typedef enum {
    /* === 成功狀態 === */
    TCA9548_OK = 0,             // 操作成功

    /* === 初始化與硬體狀態 === */
    TCA9548_ERR_INIT,           // 初始化失敗 (例如晶片上電沒反應)
    TCA9548_ERR_NOT_READY,      // 設備未就緒 (可能正在重置或未供電)

    /* === 參數與邏輯錯誤 (軟體端) === */
    TCA9548_ERR_INVALID_CH,     // 無效的通道編號 (例如傳入大於 7 的數字)
    TCA9548_ERR_INVALID_PARAM,  // 無效的參數 (例如傳入 NULL 指標)

    /* === 通訊與匯流排錯誤 (硬體端) === */
    TCA9548_ERR_COMM,           // I2C 通訊失敗 (NACK 或一般錯誤)
    TCA9548_ERR_TIMEOUT,        // I2C 通訊超時 (HAL_TIMEOUT)
    TCA9548_ERR_BUS_BUSY,       // I2C 匯流排忙碌 (HAL_BUSY，可能被其他中斷卡住)
    TCA9548_ERR_BUS_FAULT       // 匯流排錯誤 (例如 SDA/SCL 短路導致 Hard Fault)

} TCA9548_Status;
#endif


#define EEPROM_SIZE 4096  // AT24C32容量
#define MAX_READ_LEN 32   // 推荐单次读取长度
#define MAX_EEPROM_WRITE_SIZE 32


#ifdef EEPROM_with_ds1370
#define EEPROM_I2C_ADDR        0x50       // 设备7位地址
#endif

#ifdef EEPROM_with_AT24C02
#define EEPROM_I2C_ADDR        0x57       // 设备7位地址 A0=1,A1=1,A2=1
//#define EEPROM_I2C_ADDR        0x50       // 设备7位地址 A0=0,A1=0,A2=0
#endif

#define EEPROM_MAX_ADDR        	0x0FFF
#define I2C_HANDLE        		hi2c1      // 使用的I2C实例
#define EEPROM_PAGE_SIZE        32         // 设备页大小
#define EEPROM_PWR_CTRL_ENABLE  false      // 是否启用电源控制功能

#if EEPROM_PWR_CTRL_ENABLE
  #define EEPROM_PWR_GPIO        GPIOB
  #define EEPROM_PWR_PIN         GPIO_PIN_12
#endif

//RTC
/**
 *
 * RTC 相關參數設定
 *
 * 因為之前只有用到DS1307這個RTC，所以沒有考慮到『其他類型』的RTC
 * 才會決定把所有的參數以及函數的命名全部模糊化,
 * 不然時間久了，會搞不清誰是誰。
 * 目前的案例，是DS1307和DS3231，因為是同系例的產品，所以絕大多數的暫存器參數都可以共用；
 * 只要不設定鬧鐘，只有溫度的暫存器需要新增,其餘都可以共用
 *
 *
 * */

//<DS3231專屬>
#ifdef RTC_DS3231_Temp	         //如果有溫度的話,可以改變這個暫存器
#define RTC_TEMP_MSB_REG  0x11	 // MSB (0x11) 包含整數部分和小數點前兩位
#define RTC_TEMP_LSB_REG  0x12	 // LSB (0x12) 包含小數點後兩位 (0.25°C 的解析度)
#endif
//</DS3231專屬>

#define RTC_I2C_ADDR    	0x68     // RTC 的 I2C 地址
#define RTC_TIME_REG    	0x00     // 时间寄存器起始地址
#define RTC_CTRL_REG    	0x07     // 控制寄存器地址

#define RTC_REG_SECOND 		0x00 	// 秒（BCD格式，bit7 = CH，1 表示停止振盪器）
#define RTC_REG_MINUTE 		0x01	// 分（BCD格式）
#define RTC_REG_HOUR  		0x02	// 時（BCD格式，支援12/24小時模式）
#define RTC_REG_DOW    		0x03	// 星期（1=星期日 ~ 7=星期六）
#define RTC_REG_DATE   		0x04	// 日（BCD格式）
#define RTC_REG_MONTH  		0x05	// 月（BCD格式）
#define RTC_REG_YEAR   		0x06	// 年（BCD格式，範圍 00~99）
#define RTC_REG_CONTROL 	0x07	// 控制暫存器（可啟用方波輸出 SQW/OUT）

#define RTC_REG_UTC_HR		0x08	// [自定義] UTC 小時偏移（例如 +8）
#define RTC_REG_UTC_MIN		0x09	// [自定義] UTC 分鐘偏移（例如 +30）
#define RTC_REG_CENT    	0x10	// [自定義] 世紀（例如 20 = 表示年份為 20xx）
#define RTC_REG_RAM   		0x11	// [自定義] RAM 起始位置（RTC有56 bytes SRAM）
#define RTC_TIMEOUT			1000	// I2C timeout 時間（毫秒）


// 时间结构体定义（与RTC寄存器对应）
typedef struct {
	uint8_t year;
    uint8_t month;
    uint8_t date;
    uint8_t hours;
    uint8_t minutes;
	uint8_t seconds;
    uint8_t day;
    uint8_t Command_ID;
    uint8_t checksum;
} RTC_Time;

typedef struct {
	int8_t Integer;   // 整數部分
    uint8_t Fraction; // 小數部分, 單位 0.25°C (0,1,2,3)
}DS3231_Temp;

typedef struct {
	int year;
	int month;
	int day;
    int date;
	int hour;
	int minute;
	int second;
} DateAndTime;



/**
 *  @struct Point EEPROM_Status
 *  @brief I2C的錯誤碼
 * */

/* 错误代码定义 --------------------------------------------------------------*/
typedef enum {
  EEPROM_OK = 0,
  EEPROM_ERR_INIT,		//I2C initialization failed
  EEPROM_ERR_COMM,		//I2C communication failed
  EEPROM_ERR_CRC,		//I2C CRC failed
  EEPROM_ERR_ADDR,		//I2C Address failed
  EEPROM_ERR_POWER,  	//Power Control failed
  EEPROM_ERR_TIMEOUT,	//I2C communication Time out failed
  EEPROM_ERR_BUS_BUSY,	//I2C BUS BUSY
  EEPROM_ERR_Size		//over EEPROM Size
} EEPROM_Status;

typedef enum {
  I2C_OK = 0,
  I2C_ERR_INIT,		//I2C initialization failed
  I2C_ERR_COMM,		//I2C communication failed
  I2C_ERR_CRC,		//I2C CRC failed
  I2C_ERR_ADDR,		//I2C Address failed
  I2C_ERR_POWER,  	//Power Control failed
  I2C_ERR_TIMEOUT,	//I2C communication Time out failed
  I2C_ERR_BUS_BUSY,	//I2C BUS BUSY
  I2C_ERR_Size		//over EEPROM Size
} I2C_Status;



/* 健康状态结构体 ------------------------------------------------------------*/
typedef struct {
  uint32_t last_op_time;
  uint16_t write_count;
  uint16_t read_count;
  uint8_t  error_count;
  uint8_t  hw_status;
} EEPROM_Health;

/* 公开API -------------------------------------------------------------------*/
//EEPROM_Status EEPROM_Init(I2C_HandleTypeDef *hi2c);
//EEPROM_Status EEPROM_Write(uint16_t addr, uint8_t *data, uint16_t size);
//EEPROM_Status EEPROM_Read(uint16_t addr, uint8_t *data, uint16_t size);


#endif /* INC_I2C_PARAMETER_H_ */
