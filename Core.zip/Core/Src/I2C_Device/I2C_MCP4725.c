/*
 * I2C_MCP4725.C
 *
 *  Created on: 2026年11月1日
 *      Author: Ethan
 */


#include "I2C_Device\I2C_MCP4725.h"

/**
 * @brief 初始化 MCP4725 (確認設備在位)
 */
HAL_StatusTypeDef MCP4725_Init(void) {

#ifdef use_TCA9548
	if(TCA9548_SelectByAddress(MCP4725_I2C_ADDR) != HAL_OK){

		printf("MCP4725_ADC not exist, or Not connected to TCA9548");
	}else{
		TCA9548_ShowChAndAddress_SelectByAddress(MCP4725_I2C_ADDR,"MCP4725_ADC");
	}

#endif
		// 檢查設備是否在匯流排上
		if (HAL_I2C_IsDeviceReady(hi2c_main, MCP4725_I2C_ADDR << 1, 3, 100) != HAL_OK) {
			return HAL_ERROR;
		}

	    // 強制讓輸出歸零 (安全狀態)
	    // 這樣就算之前 EEPROM 記著 3.3V，現在也會被強制拉回 0V
	    MCP4725_SetRawValue(0);

		return HAL_OK;
	}


int MCP4725_DeviceInit_Wrapper(void) {
    // 假設你的 handler 是 &hi2c1
	    return (int)MCP4725_Init() ; // 假設 EEPROM_DeviceInit 回傳 I2C_Status，I2C_OK 通常是 0
	}



/**
 * @brief 直接寫入 12-bit 原始數值 (0 ~ 4095)
 * @param value 0~4095，對應 0V ~ VCC
 */
HAL_StatusTypeDef MCP4725_SetRawValue(uint16_t value) {
    if (value > 4095) value = 4095; // 限制在 12-bit 範圍內

    uint8_t buffer[3];
    // 第一 Byte：指令。0x40 代表「快速寫入 DAC，不寫入 EEPROM」
    // 如果要用斷電記憶，把 0x40 改成 0x60 即可
    buffer[0] = MCP4725_CMD_WRITE_DAC;

    // 第二 Byte：DAC 數值的高 8 位 (Bit 11 ~ Bit 4)
    buffer[1] = (value >> 4) & 0xFF;

    // 第三 Byte：DAC 數值的低 4 位 (Bit 3 ~ Bit 0)，放在最高的 4 個 bit
    buffer[2] = (value << 4) & 0xF0;

    // 發送資料 (MCP4725 不需要暫存器位址，直接寫入)
    return HAL_I2C_Master_Transmit(hi2c_main, MCP4725_I2C_ADDR << 1, buffer, 3, 100);
}

/**
 * @brief 根據目標電壓，計算並輸出對應的數值
 * @param voltage 目標電壓 (例如 1.5V)
 * @param vref    參考電壓 (MCP4725 的 VCC，例如 3.3V 或 5.0V)
 */
HAL_StatusTypeDef MCP4725_SetVoltage(float voltage, float vref) {
    // 防呆：電壓不能超過參考電壓
    if (voltage >= vref) {
        return MCP4725_SetRawValue(4095);
    }
    if (voltage <= 0.0f) {
        return MCP4725_SetRawValue(0);
    }

    // 計算公式： Value = (Voltage / Vref) * 4095
    uint16_t value = (uint16_t)((voltage / vref) * 4095.0f);

    return MCP4725_SetRawValue(value);
}


/*	這個程式基本上是利用 MCP4725來產生一個正弦波
 * 	在目前的程式碼中,受限於i2C的速度,最高極限只有9到11Hz的頻率
 *	就算改成400k,也僅僅提昇了四倍而已
 *	因為MCP4725本來就不是用來做波形產生器的
 * */
void mcp4725_sinWave_test(void) {
    // 把正弦波表放在這裡，加上 static 避免每次呼叫都重新建立
    static const uint16_t sin_table[256] = {
        2048, 2098, 2148, 2198, 2248, 2298, 2348, 2398, 2447, 2496, 2545, 2594, 2642, 2690, 2737, 2784,
        2831, 2877, 2923, 2968, 3013, 3057, 3100, 3143, 3185, 3227, 3267, 3307, 3346, 3385, 3422, 3459,
        3495, 3530, 3564, 3598, 3630, 3662, 3692, 3721, 3750, 3777, 3804, 3829, 3853, 3876, 3898, 3919,
        3939, 3958, 3975, 3992, 4007, 4021, 4033, 4045, 4055, 4064, 4071, 4077, 4082, 4085, 4087, 4088,
        4088, 4088, 4087, 4085, 4082, 4077, 4071, 4064, 4055, 4045, 4033, 4021, 4007, 3992, 3975, 3958,
        3939, 3919, 3898, 3876, 3853, 3829, 3804, 3777, 3750, 3721, 3692, 3662, 3630, 3598, 3564, 3530,
        3495, 3459, 3422, 3385, 3346, 3307, 3267, 3227, 3185, 3143, 3100, 3057, 3013, 2968, 2923, 2877,
        2831, 2784, 2737, 2690, 2642, 2594, 2545, 2496, 2447, 2398, 2348, 2298, 2248, 2198, 2148, 2098,
        2048, 1998, 1948, 1898, 1848, 1798, 1748, 1698, 1649, 1600, 1551, 1502, 1454, 1406, 1359, 1312,
        1265, 1219, 1173, 1128, 1083, 1039, 996, 953, 911, 869, 829, 789, 750, 711, 674, 637,
        601, 566, 532, 498, 466, 434, 404, 375, 346, 319, 292, 267, 243, 220, 198, 177,
        157, 138, 121, 104, 89, 75, 63, 51, 41, 32, 25, 19, 14, 11, 9, 8,
        8, 8, 9, 11, 14, 19, 25, 32, 41, 51, 63, 75, 89, 104, 121, 138,
        157, 177, 198, 220, 243, 267, 292, 319, 346, 375, 404, 434, 466, 498, 532, 566,
        601, 637, 674, 711, 750, 789, 829, 869, 911, 953, 996, 1039, 1083, 1128, 1173, 1219,
        1265, 1312, 1359, 1406, 1454, 1502, 1551, 1600, 1649, 1698, 1748, 1798, 1848, 1898, 1948, 1998
    };

    // 1. 確保通道正確
    if (TCA9548_SelectByAddress(0x61) != HAL_OK) {
        printf("MCP4725 Error: Cannot select channel\n");
        return; // 如果切換失敗，直接退出函式
    }

    // 2. 跑完一次完整的正弦波 (0 ~ 255)
    for (int i = 0; i < 256; i++) {
        MCP4725_SetRawValue(sin_table[i]);

        // 如果你想控制波形的「播放速度」，可以在這裡加延遲
        // 但目前我們用 400kHz 全速跑，所以不加延遲
    }
}
